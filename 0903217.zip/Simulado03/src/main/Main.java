/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

/**
 *
 * @author ufabc
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int min=5000, max=10000,cont=0;
        for(int i=min; i<=max;i++){
            System.out.println("Valor atual= "+i+"; Soma dos divisores= "+somaDivisores(i));
            if(somaDivisores(i)>i){
                cont++;
            }
        }
        System.out.println(cont);
    }
    static int somaDivisores(int n){
        int soma=0;
        for(int i=n-1; i>0;i--){
            if(n%i==0){
                soma = soma + i;
            }
        }
        return soma;
    }
    
}
