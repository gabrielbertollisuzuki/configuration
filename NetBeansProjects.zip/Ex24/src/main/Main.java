/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

/**
 *
 * @author g.suzuki
 */
import java.util.*;
public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        double P=1;
        for(int i=1; i<=n; i++){
            P=P*((4.0*Math.pow(i,2))/((4*Math.pow(i,2))-1));
        }
        System.out.println(2*P);
    }
    
}
